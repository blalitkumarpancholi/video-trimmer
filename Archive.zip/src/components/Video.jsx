// src/App.jsx or src/App.tsx
import React, { useState , useRef} from 'react';
import ReactPlayer from 'react-player';
import { VideoToFrames,VideoToFramesMethod } from './VideoToFrame.ts';
function Video() {
  const [videoURL, setVideoURL] = useState(null);
  const [images, setImages] = useState([]);
  const [loading,setLoading] = useState(false) 
  const fileInputRef = useRef(null);
  const [dragging, setDragging] = useState(false);


  const handleVideoChange = async (event) => {
    const file = event.target.files?.[0];
    if (file) {
        setLoading(true)
      const videoURL = URL.createObjectURL(file);
      setVideoURL(videoURL);
      const frames = await VideoToFrames.getFrames(
        videoURL,
        15,
        VideoToFramesMethod.totalFrames
      );

      setLoading(false)
     setImages(frames);
    }
  };

  const handleDrop = async (event) => {
    event.preventDefault();
    setDragging(false);

    const file = event.dataTransfer.files?.[0];
    if (file) {
      setLoading(true);

      const videoURL = URL.createObjectURL(file);
      setVideoURL(videoURL);
      const frames = await VideoToFrames.getFrames(
        videoURL,
        15,
        VideoToFramesMethod.totalFrames
      );

      setLoading(false);
      setImages(frames);
    }
  };
  const now = new Date().toDateString();

  const handleDragOver = (event) => {
    event.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => {
    setDragging(false);
  };

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  return (
    <>
    <div className="App min-h-screen flex flex-col items-center justify-center bg-white-low py-10 main-transition"
    onDrop={handleDrop}
    onDragOver={handleDragOver}
    onDragLeave={handleDragLeave}
    >
        {dragging && 
        <div className='min-h-screen w-screen absolute bg-purple-800  left-0 top-0 flex justify-center items-center main-transition'>
          <div className='text-white text-center lg:text-5xl md:text-4xl sm:text-2xl text-xl  font-bold mb-4'>Drop any where</div>
        </div>
        }
      {!videoURL &&  
      (
      <>
      <div className='text-slate-900 text-center 2xl:text-[5rem] xl:text-[4rem] lg:text-5xl md:text-4xl sm:text-2xl text-xl  font-bold mb-4'>Trim Video API</div>
      <div className='text-center mb-20 lg:text-xl sm:text-base text-gray-400 font-semibold'>Fast, accurate video trimmer. Try it below</div>
      <div className="max-w-lg flex flex-col w-full p-36 bg-img rounded-lg border-4 border-white shadow-lg" 
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}>
        <input
          type="file"
          accept="video/*,.mkv"
          onChange={handleVideoChange}
          className="my-2 hidden"
          ref={fileInputRef}  
        />

        <button className='px-5 py-4 bg-purple-800 text-white font-semibold text-lg rounded-md flex justify-center space-x-2' onClick={handleButtonClick}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        > <span>Start from a Video</span></button>
        <div className='text-center text-slate-800 font-semibold mt-5'>Or drop a video here</div>
      </div>
      </>
      )}

      {loading === true && !videoURL && (
        <div className="h-1/4 shimmer-effect p-6 rounded-xl shadow-lg bg-white w-1/2 ">
      </div>
      )}

      {videoURL  && (
          <div className="custom-player-container  flex justify-center p-6 rounded-xl shadow-lg bg-white w-1/2 ">
            <ReactPlayer
              url={videoURL}
              controls
              width="100%"
              height="100%"       
            />
          </div>
        )}

{images?.length <=0 && loading === true && (
  <div className="output flex overflow-x-scroll mt-5 mx-44 space-x-3">
    <div className='w-44 rounded-md h-20 shimmer-effect bg-gray-400'></div>
    <div className='w-44 rounded-md h-20 shimmer-effect bg-gray-400'></div>
    <div className='w-44 rounded-md h-20 shimmer-effect bg-gray-400'></div>
    <div className='w-44 rounded-md h-20 shimmer-effect bg-gray-400'></div>
    <div className='w-44 rounded-md h-20 shimmer-effect bg-gray-400'></div>
    <div className='w-44 rounded-md h-20 shimmer-effect bg-gray-400'></div>
    <div className='w-44 rounded-md h-20 shimmer-effect bg-gray-400'></div>
  </div>
)}

{images?.length > 0 && (
        <div className="output flex overflow-x-scroll mt-5 mx-44 space-x-3">
          {images.map((imageUrl, index) => (
              <img src={imageUrl} alt="" className='w-44 rounded-md' />
          ))}
        </div>
      )}
    </div>
    </>
  );
}

export default Video;
