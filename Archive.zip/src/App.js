import Video from './components/Video';
import './App.css';

function App() {
  return (
    <>
<Video/>
    </>
  );
}

export default App;
